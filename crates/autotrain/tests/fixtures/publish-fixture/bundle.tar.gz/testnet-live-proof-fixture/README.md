# STW-032 publish-fixture

A committed no-DB portable reference bundle for the
STW-032 publish step. The fixture is a synthetic
green receipt + the deterministic
`trainer --publish <receipt>` bundle a CI auditor
can re-verify without a live Postgres.

Do NOT edit the bundle files by hand. To regenerate:

    rm -rf crates/autotrain/tests/fixtures/publish-fixture
    python3 scripts/_build_publish_fixture.py

The lib test
`publish::tests::run_verifies_committed_publish_fixture`
re-verifies the bundle on every `cargo test
--workspace` run.
